﻿namespace QuanLiSinhVien
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label1;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.heThongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chucNangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timKiemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoongsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thongTinSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel_lop = new System.Windows.Forms.Panel();
            this.groupBox_lop = new System.Windows.Forms.GroupBox();
            this.comboBox_tenK_k = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_khoahoc_l = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_tenlop_l = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_malop_l = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.dataGridView_lop = new System.Windows.Forms.DataGridView();
            this.groupBox_gv = new System.Windows.Forms.GroupBox();
            this.dateTimePicker_nsGV = new System.Windows.Forms.DateTimePicker();
            this.comboBox_mhGV = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox_tenKhoa_GV = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_sdtGV = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_dcGV = new System.Windows.Forms.TextBox();
            this.textBox_hotenGV = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox_magv = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.dataGridView_gv = new System.Windows.Forms.DataGridView();
            this.groupBox_sv = new System.Windows.Forms.GroupBox();
            this.dateTimePicker_nssv = new System.Windows.Forms.DateTimePicker();
            this.comboBox_tenLop = new System.Windows.Forms.ComboBox();
            this.radioButton_nu = new System.Windows.Forms.RadioButton();
            this.radioButton_nam = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_sdtSV = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox_dichi_sv = new System.Windows.Forms.TextBox();
            this.textBox_hoten_sv = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textbox_masv = new System.Windows.Forms.TextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.dataGridView_sv = new System.Windows.Forms.DataGridView();
            this.groupBox_mh = new System.Windows.Forms.GroupBox();
            this.textBox_tenmh_mh = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox_mamh_mh = new System.Windows.Forms.TextBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.dataGridView_mh = new System.Windows.Forms.DataGridView();
            this.groupBox_khoa = new System.Windows.Forms.GroupBox();
            this.textBox_tenKhoa_k = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_makhoa_k = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.dataGridView_khoa = new System.Windows.Forms.DataGridView();
            this.groupBox_diem = new System.Windows.Forms.GroupBox();
            this.comboBox_masv_d = new System.Windows.Forms.ComboBox();
            this.comboBox_mamh_d = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox_diemCK = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox_diemGK = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.dataGridView_diem = new System.Windows.Forms.DataGridView();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.menuStrip2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel_lop.SuspendLayout();
            this.groupBox_lop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_lop)).BeginInit();
            this.groupBox_gv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_gv)).BeginInit();
            this.groupBox_sv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_sv)).BeginInit();
            this.groupBox_mh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_mh)).BeginInit();
            this.groupBox_khoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_khoa)).BeginInit();
            this.groupBox_diem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_diem)).BeginInit();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            label1.Location = new System.Drawing.Point(12, 17);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(26, 13);
            label1.TabIndex = 0;
            label1.Text = "Ten";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.heThongToolStripMenuItem,
            this.chucNangToolStripMenuItem,
            this.timKiemToolStripMenuItem,
            this.thoongsToolStripMenuItem,
            this.thongTinSToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // heThongToolStripMenuItem
            // 
            this.heThongToolStripMenuItem.Name = "heThongToolStripMenuItem";
            this.heThongToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.heThongToolStripMenuItem.Text = "Hệ thống";
            // 
            // chucNangToolStripMenuItem
            // 
            this.chucNangToolStripMenuItem.Name = "chucNangToolStripMenuItem";
            this.chucNangToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.chucNangToolStripMenuItem.Text = "Chức năng";
            // 
            // timKiemToolStripMenuItem
            // 
            this.timKiemToolStripMenuItem.Name = "timKiemToolStripMenuItem";
            this.timKiemToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.timKiemToolStripMenuItem.Text = "Tìm kiếm";
            // 
            // thoongsToolStripMenuItem
            // 
            this.thoongsToolStripMenuItem.Name = "thoongsToolStripMenuItem";
            this.thoongsToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thoongsToolStripMenuItem.Text = "Thống kê";
            this.thoongsToolStripMenuItem.Click += new System.EventHandler(this.thoongsToolStripMenuItem_Click);
            // 
            // thongTinSToolStripMenuItem
            // 
            this.thongTinSToolStripMenuItem.Name = "thongTinSToolStripMenuItem";
            this.thongTinSToolStripMenuItem.Size = new System.Drawing.Size(127, 20);
            this.thongTinSToolStripMenuItem.Text = "Thông tin phần mền";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 426);
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 324);
            this.panel3.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 50);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(178, 274);
            this.panel5.TabIndex = 1;
            this.panel5.Tag = "";
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 90;
            this.button6.Location = new System.Drawing.Point(35, 150);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(119, 23);
            this.button6.TabIndex = 5;
            this.button6.Text = "Điểm";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 90;
            this.button5.Location = new System.Drawing.Point(35, 121);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(119, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Môn học";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 90;
            this.button4.Location = new System.Drawing.Point(35, 92);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(119, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Khoa";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 90;
            this.button3.Location = new System.Drawing.Point(35, 34);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Giáo viên";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 90;
            this.button2.Location = new System.Drawing.Point(35, 63);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Lớp";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 90;
            this.button1.Location = new System.Drawing.Point(35, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Sinh viên";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(178, 50);
            this.panel4.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 50);
            this.label3.TabIndex = 0;
            this.label3.Text = "Menu";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(178, 100);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(118, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tuoi";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel_lop);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(180, 24);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(620, 426);
            this.panel6.TabIndex = 3;
            // 
            // panel_lop
            // 
            this.panel_lop.Controls.Add(this.groupBox_lop);
            this.panel_lop.Controls.Add(this.groupBox_gv);
            this.panel_lop.Controls.Add(this.groupBox_sv);
            this.panel_lop.Controls.Add(this.groupBox_mh);
            this.panel_lop.Controls.Add(this.groupBox_khoa);
            this.panel_lop.Controls.Add(this.groupBox_diem);
            this.panel_lop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_lop.Location = new System.Drawing.Point(0, 100);
            this.panel_lop.Name = "panel_lop";
            this.panel_lop.Size = new System.Drawing.Size(620, 326);
            this.panel_lop.TabIndex = 1;
            // 
            // groupBox_lop
            // 
            this.groupBox_lop.Controls.Add(this.comboBox_tenK_k);
            this.groupBox_lop.Controls.Add(this.label9);
            this.groupBox_lop.Controls.Add(this.label8);
            this.groupBox_lop.Controls.Add(this.textBox_khoahoc_l);
            this.groupBox_lop.Controls.Add(this.label7);
            this.groupBox_lop.Controls.Add(this.textBox_tenlop_l);
            this.groupBox_lop.Controls.Add(this.label6);
            this.groupBox_lop.Controls.Add(this.label5);
            this.groupBox_lop.Controls.Add(this.textBox_malop_l);
            this.groupBox_lop.Controls.Add(this.button10);
            this.groupBox_lop.Controls.Add(this.button9);
            this.groupBox_lop.Controls.Add(this.button8);
            this.groupBox_lop.Controls.Add(this.button7);
            this.groupBox_lop.Controls.Add(this.dataGridView_lop);
            this.groupBox_lop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_lop.Location = new System.Drawing.Point(0, 0);
            this.groupBox_lop.Name = "groupBox_lop";
            this.groupBox_lop.Size = new System.Drawing.Size(620, 326);
            this.groupBox_lop.TabIndex = 0;
            this.groupBox_lop.TabStop = false;
            this.groupBox_lop.Text = "Thông tin lớp";
            this.groupBox_lop.Visible = false;
            // 
            // comboBox_tenK_k
            // 
            this.comboBox_tenK_k.FormattingEnabled = true;
            this.comboBox_tenK_k.Location = new System.Drawing.Point(446, 109);
            this.comboBox_tenK_k.Name = "comboBox_tenK_k";
            this.comboBox_tenK_k.Size = new System.Drawing.Size(119, 21);
            this.comboBox_tenK_k.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(419, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 19);
            this.label9.TabIndex = 16;
            this.label9.Text = "Nhập thông tin lớp";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(380, 190);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "Khóa học";
            // 
            // textBox_khoahoc_l
            // 
            this.textBox_khoahoc_l.Location = new System.Drawing.Point(446, 185);
            this.textBox_khoahoc_l.Name = "textBox_khoahoc_l";
            this.textBox_khoahoc_l.Size = new System.Drawing.Size(119, 20);
            this.textBox_khoahoc_l.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(380, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Tên lớp";
            // 
            // textBox_tenlop_l
            // 
            this.textBox_tenlop_l.Location = new System.Drawing.Point(446, 149);
            this.textBox_tenlop_l.Name = "textBox_tenlop_l";
            this.textBox_tenlop_l.Size = new System.Drawing.Size(119, 20);
            this.textBox_tenlop_l.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(380, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Tên khoa";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(380, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mã lớp";
            // 
            // textBox_malop_l
            // 
            this.textBox_malop_l.Location = new System.Drawing.Point(446, 72);
            this.textBox_malop_l.Name = "textBox_malop_l";
            this.textBox_malop_l.ReadOnly = true;
            this.textBox_malop_l.Size = new System.Drawing.Size(119, 20);
            this.textBox_malop_l.TabIndex = 5;
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderSize = 90;
            this.button10.Location = new System.Drawing.Point(20, 268);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(116, 44);
            this.button10.TabIndex = 4;
            this.button10.Text = "Thêm";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderSize = 90;
            this.button9.Location = new System.Drawing.Point(158, 268);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(119, 44);
            this.button9.TabIndex = 3;
            this.button9.Text = "Cập nhật";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 90;
            this.button8.Location = new System.Drawing.Point(300, 268);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(119, 44);
            this.button8.TabIndex = 2;
            this.button8.Text = "Xóa";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.FlatAppearance.BorderSize = 90;
            this.button7.Location = new System.Drawing.Point(446, 268);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(119, 44);
            this.button7.TabIndex = 1;
            this.button7.Text = "Reset";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // dataGridView_lop
            // 
            this.dataGridView_lop.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_lop.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_lop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_lop.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_lop.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_lop.Name = "dataGridView_lop";
            this.dataGridView_lop.RowHeadersVisible = false;
            this.dataGridView_lop.Size = new System.Drawing.Size(306, 195);
            this.dataGridView_lop.TabIndex = 0;
            this.dataGridView_lop.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click_lop);
            // 
            // groupBox_gv
            // 
            this.groupBox_gv.Controls.Add(this.dateTimePicker_nsGV);
            this.groupBox_gv.Controls.Add(this.comboBox_mhGV);
            this.groupBox_gv.Controls.Add(this.label19);
            this.groupBox_gv.Controls.Add(this.comboBox_tenKhoa_GV);
            this.groupBox_gv.Controls.Add(this.label18);
            this.groupBox_gv.Controls.Add(this.textBox_sdtGV);
            this.groupBox_gv.Controls.Add(this.label20);
            this.groupBox_gv.Controls.Add(this.textBox_dcGV);
            this.groupBox_gv.Controls.Add(this.textBox_hotenGV);
            this.groupBox_gv.Controls.Add(this.label21);
            this.groupBox_gv.Controls.Add(this.label22);
            this.groupBox_gv.Controls.Add(this.label23);
            this.groupBox_gv.Controls.Add(this.label24);
            this.groupBox_gv.Controls.Add(this.label25);
            this.groupBox_gv.Controls.Add(this.textBox_magv);
            this.groupBox_gv.Controls.Add(this.button15);
            this.groupBox_gv.Controls.Add(this.button16);
            this.groupBox_gv.Controls.Add(this.button17);
            this.groupBox_gv.Controls.Add(this.button18);
            this.groupBox_gv.Controls.Add(this.dataGridView_gv);
            this.groupBox_gv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_gv.Location = new System.Drawing.Point(0, 0);
            this.groupBox_gv.Name = "groupBox_gv";
            this.groupBox_gv.Size = new System.Drawing.Size(620, 326);
            this.groupBox_gv.TabIndex = 2;
            this.groupBox_gv.TabStop = false;
            this.groupBox_gv.Text = "Thông tin giảng viên";
            this.groupBox_gv.Visible = false;
            // 
            // dateTimePicker_nsGV
            // 
            this.dateTimePicker_nsGV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_nsGV.Location = new System.Drawing.Point(372, 201);
            this.dateTimePicker_nsGV.Name = "dateTimePicker_nsGV";
            this.dateTimePicker_nsGV.Size = new System.Drawing.Size(78, 20);
            this.dateTimePicker_nsGV.TabIndex = 26;
            // 
            // comboBox_mhGV
            // 
            this.comboBox_mhGV.FormattingEnabled = true;
            this.comboBox_mhGV.Location = new System.Drawing.Point(529, 122);
            this.comboBox_mhGV.Name = "comboBox_mhGV";
            this.comboBox_mhGV.Size = new System.Drawing.Size(76, 21);
            this.comboBox_mhGV.TabIndex = 25;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(469, 84);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 15);
            this.label19.TabIndex = 24;
            this.label19.Text = "Tên khoa";
            // 
            // comboBox_tenKhoa_GV
            // 
            this.comboBox_tenKhoa_GV.FormattingEnabled = true;
            this.comboBox_tenKhoa_GV.Location = new System.Drawing.Point(529, 82);
            this.comboBox_tenKhoa_GV.Name = "comboBox_tenKhoa_GV";
            this.comboBox_tenKhoa_GV.Size = new System.Drawing.Size(76, 21);
            this.comboBox_tenKhoa_GV.TabIndex = 23;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(289, 164);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 15);
            this.label18.TabIndex = 22;
            this.label18.Text = "Số điện thoại";
            // 
            // textBox_sdtGV
            // 
            this.textBox_sdtGV.Location = new System.Drawing.Point(372, 159);
            this.textBox_sdtGV.Name = "textBox_sdtGV";
            this.textBox_sdtGV.Size = new System.Drawing.Size(78, 20);
            this.textBox_sdtGV.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(475, 163);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 15);
            this.label20.TabIndex = 19;
            this.label20.Text = "Địa chỉ";
            // 
            // textBox_dcGV
            // 
            this.textBox_dcGV.Location = new System.Drawing.Point(529, 158);
            this.textBox_dcGV.Name = "textBox_dcGV";
            this.textBox_dcGV.Size = new System.Drawing.Size(78, 20);
            this.textBox_dcGV.TabIndex = 18;
            // 
            // textBox_hotenGV
            // 
            this.textBox_hotenGV.Location = new System.Drawing.Point(372, 119);
            this.textBox_hotenGV.Name = "textBox_hotenGV";
            this.textBox_hotenGV.Size = new System.Drawing.Size(78, 20);
            this.textBox_hotenGV.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(386, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(161, 19);
            this.label21.TabIndex = 16;
            this.label21.Text = "Nhập thông tin giảng viên";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(289, 201);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 15);
            this.label22.TabIndex = 15;
            this.label22.Text = "Ngày sinh";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(469, 124);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 15);
            this.label23.TabIndex = 13;
            this.label23.Text = "Môn dạy";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(289, 124);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 15);
            this.label24.TabIndex = 11;
            this.label24.Text = "Họ tên";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(289, 88);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 15);
            this.label25.TabIndex = 9;
            this.label25.Text = "Mã giáo viên";
            // 
            // textBox_magv
            // 
            this.textBox_magv.Location = new System.Drawing.Point(372, 83);
            this.textBox_magv.Name = "textBox_magv";
            this.textBox_magv.ReadOnly = true;
            this.textBox_magv.Size = new System.Drawing.Size(78, 20);
            this.textBox_magv.TabIndex = 5;
            // 
            // button15
            // 
            this.button15.FlatAppearance.BorderSize = 90;
            this.button15.Location = new System.Drawing.Point(320, 241);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(119, 32);
            this.button15.TabIndex = 4;
            this.button15.Text = "Thêm";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.FlatAppearance.BorderSize = 90;
            this.button16.Location = new System.Drawing.Point(466, 241);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(119, 32);
            this.button16.TabIndex = 3;
            this.button16.Text = "Cập nhật";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.FlatAppearance.BorderSize = 90;
            this.button17.Location = new System.Drawing.Point(320, 279);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(119, 32);
            this.button17.TabIndex = 2;
            this.button17.Text = "Xóa";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.FlatAppearance.BorderSize = 90;
            this.button18.Location = new System.Drawing.Point(466, 279);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(119, 32);
            this.button18.TabIndex = 1;
            this.button18.Text = "Reset";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // dataGridView_gv
            // 
            this.dataGridView_gv.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_gv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_gv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_gv.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_gv.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_gv.Name = "dataGridView_gv";
            this.dataGridView_gv.RowHeadersVisible = false;
            this.dataGridView_gv.Size = new System.Drawing.Size(257, 261);
            this.dataGridView_gv.TabIndex = 0;
            this.dataGridView_gv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.double_click_gv);
            // 
            // groupBox_sv
            // 
            this.groupBox_sv.Controls.Add(this.dateTimePicker_nssv);
            this.groupBox_sv.Controls.Add(this.comboBox_tenLop);
            this.groupBox_sv.Controls.Add(this.radioButton_nu);
            this.groupBox_sv.Controls.Add(this.radioButton_nam);
            this.groupBox_sv.Controls.Add(this.label15);
            this.groupBox_sv.Controls.Add(this.textBox_sdtSV);
            this.groupBox_sv.Controls.Add(this.label16);
            this.groupBox_sv.Controls.Add(this.label17);
            this.groupBox_sv.Controls.Add(this.textBox_dichi_sv);
            this.groupBox_sv.Controls.Add(this.textBox_hoten_sv);
            this.groupBox_sv.Controls.Add(this.label10);
            this.groupBox_sv.Controls.Add(this.label11);
            this.groupBox_sv.Controls.Add(this.label12);
            this.groupBox_sv.Controls.Add(this.label13);
            this.groupBox_sv.Controls.Add(this.label14);
            this.groupBox_sv.Controls.Add(this.textbox_masv);
            this.groupBox_sv.Controls.Add(this.button11);
            this.groupBox_sv.Controls.Add(this.button12);
            this.groupBox_sv.Controls.Add(this.button13);
            this.groupBox_sv.Controls.Add(this.button14);
            this.groupBox_sv.Controls.Add(this.dataGridView_sv);
            this.groupBox_sv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_sv.Location = new System.Drawing.Point(0, 0);
            this.groupBox_sv.Name = "groupBox_sv";
            this.groupBox_sv.Size = new System.Drawing.Size(620, 326);
            this.groupBox_sv.TabIndex = 1;
            this.groupBox_sv.TabStop = false;
            this.groupBox_sv.Text = "Thông tin sinh viên";
            this.groupBox_sv.Visible = false;
            // 
            // dateTimePicker_nssv
            // 
            this.dateTimePicker_nssv.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_nssv.Location = new System.Drawing.Point(527, 156);
            this.dateTimePicker_nssv.Name = "dateTimePicker_nssv";
            this.dateTimePicker_nssv.Size = new System.Drawing.Size(80, 20);
            this.dateTimePicker_nssv.TabIndex = 26;
            // 
            // comboBox_tenLop
            // 
            this.comboBox_tenLop.FormattingEnabled = true;
            this.comboBox_tenLop.Location = new System.Drawing.Point(529, 83);
            this.comboBox_tenLop.Name = "comboBox_tenLop";
            this.comboBox_tenLop.Size = new System.Drawing.Size(78, 21);
            this.comboBox_tenLop.TabIndex = 25;
            // 
            // radioButton_nu
            // 
            this.radioButton_nu.AutoSize = true;
            this.radioButton_nu.Location = new System.Drawing.Point(445, 201);
            this.radioButton_nu.Name = "radioButton_nu";
            this.radioButton_nu.Size = new System.Drawing.Size(39, 17);
            this.radioButton_nu.TabIndex = 24;
            this.radioButton_nu.Text = "Nữ";
            this.radioButton_nu.UseVisualStyleBackColor = true;
            // 
            // radioButton_nam
            // 
            this.radioButton_nam.AutoSize = true;
            this.radioButton_nam.Location = new System.Drawing.Point(372, 201);
            this.radioButton_nam.Name = "radioButton_nam";
            this.radioButton_nam.Size = new System.Drawing.Size(47, 17);
            this.radioButton_nam.TabIndex = 23;
            this.radioButton_nam.Text = "Nam";
            this.radioButton_nam.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(289, 164);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 15);
            this.label15.TabIndex = 22;
            this.label15.Text = "Số điện thoại";
            // 
            // textBox_sdtSV
            // 
            this.textBox_sdtSV.Location = new System.Drawing.Point(372, 159);
            this.textBox_sdtSV.Name = "textBox_sdtSV";
            this.textBox_sdtSV.Size = new System.Drawing.Size(78, 20);
            this.textBox_sdtSV.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(291, 200);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 15);
            this.label16.TabIndex = 20;
            this.label16.Text = "Giới tính";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(475, 127);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 15);
            this.label17.TabIndex = 19;
            this.label17.Text = "Địa chỉ";
            // 
            // textBox_dichi_sv
            // 
            this.textBox_dichi_sv.Location = new System.Drawing.Point(529, 122);
            this.textBox_dichi_sv.Name = "textBox_dichi_sv";
            this.textBox_dichi_sv.Size = new System.Drawing.Size(78, 20);
            this.textBox_dichi_sv.TabIndex = 18;
            // 
            // textBox_hoten_sv
            // 
            this.textBox_hoten_sv.Location = new System.Drawing.Point(372, 119);
            this.textBox_hoten_sv.Name = "textBox_hoten_sv";
            this.textBox_hoten_sv.Size = new System.Drawing.Size(78, 20);
            this.textBox_hoten_sv.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(386, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 19);
            this.label10.TabIndex = 16;
            this.label10.Text = "Nhập thông tin sinh viên";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(463, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 15);
            this.label11.TabIndex = 15;
            this.label11.Text = "Ngày sinh";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(475, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 15);
            this.label12.TabIndex = 13;
            this.label12.Text = "Tên lớp";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(289, 124);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 15);
            this.label13.TabIndex = 11;
            this.label13.Text = "Họ tên";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(289, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 15);
            this.label14.TabIndex = 9;
            this.label14.Text = "Mã sinh viên";
            // 
            // textbox_masv
            // 
            this.textbox_masv.Location = new System.Drawing.Point(372, 83);
            this.textbox_masv.Name = "textbox_masv";
            this.textbox_masv.ReadOnly = true;
            this.textbox_masv.Size = new System.Drawing.Size(78, 20);
            this.textbox_masv.TabIndex = 5;
            // 
            // button11
            // 
            this.button11.FlatAppearance.BorderSize = 90;
            this.button11.Location = new System.Drawing.Point(320, 241);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(119, 32);
            this.button11.TabIndex = 4;
            this.button11.Text = "Thêm";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.FlatAppearance.BorderSize = 90;
            this.button12.Location = new System.Drawing.Point(466, 241);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(119, 32);
            this.button12.TabIndex = 3;
            this.button12.Text = "Cập nhật";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.FlatAppearance.BorderSize = 90;
            this.button13.Location = new System.Drawing.Point(320, 279);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(119, 32);
            this.button13.TabIndex = 2;
            this.button13.Text = "Xóa";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.FlatAppearance.BorderSize = 90;
            this.button14.Location = new System.Drawing.Point(466, 279);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(119, 32);
            this.button14.TabIndex = 1;
            this.button14.Text = "Reset";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // dataGridView_sv
            // 
            this.dataGridView_sv.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_sv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_sv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_sv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_sv.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView_sv.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_sv.Name = "dataGridView_sv";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_sv.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView_sv.RowHeadersVisible = false;
            this.dataGridView_sv.Size = new System.Drawing.Size(257, 261);
            this.dataGridView_sv.TabIndex = 0;
            this.dataGridView_sv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click);
            // 
            // groupBox_mh
            // 
            this.groupBox_mh.Controls.Add(this.textBox_tenmh_mh);
            this.groupBox_mh.Controls.Add(this.label27);
            this.groupBox_mh.Controls.Add(this.label28);
            this.groupBox_mh.Controls.Add(this.label31);
            this.groupBox_mh.Controls.Add(this.textBox_mamh_mh);
            this.groupBox_mh.Controls.Add(this.button23);
            this.groupBox_mh.Controls.Add(this.button24);
            this.groupBox_mh.Controls.Add(this.button25);
            this.groupBox_mh.Controls.Add(this.button26);
            this.groupBox_mh.Controls.Add(this.dataGridView_mh);
            this.groupBox_mh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_mh.Location = new System.Drawing.Point(0, 0);
            this.groupBox_mh.Name = "groupBox_mh";
            this.groupBox_mh.Size = new System.Drawing.Size(620, 326);
            this.groupBox_mh.TabIndex = 4;
            this.groupBox_mh.TabStop = false;
            this.groupBox_mh.Text = "Thông tin môn học";
            this.groupBox_mh.Visible = false;
            // 
            // textBox_tenmh_mh
            // 
            this.textBox_tenmh_mh.Location = new System.Drawing.Point(446, 123);
            this.textBox_tenmh_mh.Name = "textBox_tenmh_mh";
            this.textBox_tenmh_mh.Size = new System.Drawing.Size(119, 20);
            this.textBox_tenmh_mh.TabIndex = 17;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(419, 32);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(154, 19);
            this.label27.TabIndex = 16;
            this.label27.Text = "Nhập thông tin môn học";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(363, 127);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 15);
            this.label28.TabIndex = 11;
            this.label28.Text = "Tên môn học";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(363, 82);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 15);
            this.label31.TabIndex = 9;
            this.label31.Text = "Mã môn học";
            // 
            // textBox_mamh_mh
            // 
            this.textBox_mamh_mh.Location = new System.Drawing.Point(446, 77);
            this.textBox_mamh_mh.Name = "textBox_mamh_mh";
            this.textBox_mamh_mh.ReadOnly = true;
            this.textBox_mamh_mh.Size = new System.Drawing.Size(119, 20);
            this.textBox_mamh_mh.TabIndex = 5;
            // 
            // button23
            // 
            this.button23.FlatAppearance.BorderSize = 90;
            this.button23.Location = new System.Drawing.Point(20, 268);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(116, 44);
            this.button23.TabIndex = 4;
            this.button23.Text = "Thêm";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.FlatAppearance.BorderSize = 90;
            this.button24.Location = new System.Drawing.Point(158, 268);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(119, 44);
            this.button24.TabIndex = 3;
            this.button24.Text = "Cập nhật";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.FlatAppearance.BorderSize = 90;
            this.button25.Location = new System.Drawing.Point(300, 268);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(119, 44);
            this.button25.TabIndex = 2;
            this.button25.Text = "Xóa";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.FlatAppearance.BorderSize = 90;
            this.button26.Location = new System.Drawing.Point(446, 268);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(119, 44);
            this.button26.TabIndex = 1;
            this.button26.Text = "Reset";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // dataGridView_mh
            // 
            this.dataGridView_mh.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_mh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_mh.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView_mh.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_mh.Name = "dataGridView_mh";
            this.dataGridView_mh.RowHeadersVisible = false;
            this.dataGridView_mh.Size = new System.Drawing.Size(306, 195);
            this.dataGridView_mh.TabIndex = 0;
            this.dataGridView_mh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click_mh);
            // 
            // groupBox_khoa
            // 
            this.groupBox_khoa.Controls.Add(this.textBox_tenKhoa_k);
            this.groupBox_khoa.Controls.Add(this.label26);
            this.groupBox_khoa.Controls.Add(this.label29);
            this.groupBox_khoa.Controls.Add(this.label30);
            this.groupBox_khoa.Controls.Add(this.textBox_makhoa_k);
            this.groupBox_khoa.Controls.Add(this.button19);
            this.groupBox_khoa.Controls.Add(this.button20);
            this.groupBox_khoa.Controls.Add(this.button21);
            this.groupBox_khoa.Controls.Add(this.button22);
            this.groupBox_khoa.Controls.Add(this.dataGridView_khoa);
            this.groupBox_khoa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_khoa.Location = new System.Drawing.Point(0, 0);
            this.groupBox_khoa.Name = "groupBox_khoa";
            this.groupBox_khoa.Size = new System.Drawing.Size(620, 326);
            this.groupBox_khoa.TabIndex = 3;
            this.groupBox_khoa.TabStop = false;
            this.groupBox_khoa.Text = "Thông tin khoa";
            this.groupBox_khoa.Visible = false;
            // 
            // textBox_tenKhoa_k
            // 
            this.textBox_tenKhoa_k.Location = new System.Drawing.Point(446, 123);
            this.textBox_tenKhoa_k.Name = "textBox_tenKhoa_k";
            this.textBox_tenKhoa_k.Size = new System.Drawing.Size(119, 20);
            this.textBox_tenKhoa_k.TabIndex = 17;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(419, 32);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(132, 19);
            this.label26.TabIndex = 16;
            this.label26.Text = "Nhập thông tin khoa";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(381, 128);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 15);
            this.label29.TabIndex = 11;
            this.label29.Text = "Tên khoa";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(380, 82);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(54, 15);
            this.label30.TabIndex = 9;
            this.label30.Text = "Mã khoa";
            // 
            // textBox_makhoa_k
            // 
            this.textBox_makhoa_k.Location = new System.Drawing.Point(446, 77);
            this.textBox_makhoa_k.Name = "textBox_makhoa_k";
            this.textBox_makhoa_k.ReadOnly = true;
            this.textBox_makhoa_k.Size = new System.Drawing.Size(119, 20);
            this.textBox_makhoa_k.TabIndex = 5;
            // 
            // button19
            // 
            this.button19.FlatAppearance.BorderSize = 90;
            this.button19.Location = new System.Drawing.Point(20, 268);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(116, 44);
            this.button19.TabIndex = 4;
            this.button19.Text = "Thêm";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.FlatAppearance.BorderSize = 90;
            this.button20.Location = new System.Drawing.Point(158, 268);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(119, 44);
            this.button20.TabIndex = 3;
            this.button20.Text = "Cập nhật";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.FlatAppearance.BorderSize = 90;
            this.button21.Location = new System.Drawing.Point(300, 268);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(119, 44);
            this.button21.TabIndex = 2;
            this.button21.Text = "Xóa";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.FlatAppearance.BorderSize = 90;
            this.button22.Location = new System.Drawing.Point(446, 268);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(119, 44);
            this.button22.TabIndex = 1;
            this.button22.Text = "Reset";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // dataGridView_khoa
            // 
            this.dataGridView_khoa.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_khoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_khoa.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView_khoa.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_khoa.Name = "dataGridView_khoa";
            this.dataGridView_khoa.RowHeadersVisible = false;
            this.dataGridView_khoa.Size = new System.Drawing.Size(306, 195);
            this.dataGridView_khoa.TabIndex = 0;
            this.dataGridView_khoa.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click_khoa);
            // 
            // groupBox_diem
            // 
            this.groupBox_diem.Controls.Add(this.comboBox_masv_d);
            this.groupBox_diem.Controls.Add(this.comboBox_mamh_d);
            this.groupBox_diem.Controls.Add(this.label32);
            this.groupBox_diem.Controls.Add(this.label33);
            this.groupBox_diem.Controls.Add(this.textBox_diemCK);
            this.groupBox_diem.Controls.Add(this.label34);
            this.groupBox_diem.Controls.Add(this.textBox_diemGK);
            this.groupBox_diem.Controls.Add(this.label35);
            this.groupBox_diem.Controls.Add(this.label36);
            this.groupBox_diem.Controls.Add(this.button27);
            this.groupBox_diem.Controls.Add(this.button28);
            this.groupBox_diem.Controls.Add(this.button29);
            this.groupBox_diem.Controls.Add(this.button30);
            this.groupBox_diem.Controls.Add(this.dataGridView_diem);
            this.groupBox_diem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_diem.Location = new System.Drawing.Point(0, 0);
            this.groupBox_diem.Name = "groupBox_diem";
            this.groupBox_diem.Size = new System.Drawing.Size(620, 326);
            this.groupBox_diem.TabIndex = 5;
            this.groupBox_diem.TabStop = false;
            this.groupBox_diem.Text = "Thông tin điểm sinh viên";
            this.groupBox_diem.Visible = false;
            // 
            // comboBox_masv_d
            // 
            this.comboBox_masv_d.FormattingEnabled = true;
            this.comboBox_masv_d.Location = new System.Drawing.Point(466, 75);
            this.comboBox_masv_d.Name = "comboBox_masv_d";
            this.comboBox_masv_d.Size = new System.Drawing.Size(119, 21);
            this.comboBox_masv_d.TabIndex = 18;
            // 
            // comboBox_mamh_d
            // 
            this.comboBox_mamh_d.FormattingEnabled = true;
            this.comboBox_mamh_d.Location = new System.Drawing.Point(466, 112);
            this.comboBox_mamh_d.Name = "comboBox_mamh_d";
            this.comboBox_mamh_d.Size = new System.Drawing.Size(119, 21);
            this.comboBox_mamh_d.TabIndex = 17;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(419, 32);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(131, 19);
            this.label32.TabIndex = 16;
            this.label32.Text = "Nhập thông tin điểm";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(380, 190);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(76, 15);
            this.label33.TabIndex = 15;
            this.label33.Text = "Điểm cuối kỳ";
            // 
            // textBox_diemCK
            // 
            this.textBox_diemCK.Location = new System.Drawing.Point(466, 188);
            this.textBox_diemCK.Name = "textBox_diemCK";
            this.textBox_diemCK.Size = new System.Drawing.Size(119, 20);
            this.textBox_diemCK.TabIndex = 14;
            this.textBox_diemCK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ktSo);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(380, 154);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(76, 15);
            this.label34.TabIndex = 13;
            this.label34.Text = "Điểm giữa kỳ";
            // 
            // textBox_diemGK
            // 
            this.textBox_diemGK.Location = new System.Drawing.Point(466, 152);
            this.textBox_diemGK.Name = "textBox_diemGK";
            this.textBox_diemGK.Size = new System.Drawing.Size(119, 20);
            this.textBox_diemGK.TabIndex = 12;
            this.textBox_diemGK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ktSo);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(380, 115);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(74, 15);
            this.label35.TabIndex = 11;
            this.label35.Text = "Mã môn học";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(380, 77);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 15);
            this.label36.TabIndex = 9;
            this.label36.Text = "Mã sinh viên";
            // 
            // button27
            // 
            this.button27.FlatAppearance.BorderSize = 90;
            this.button27.Location = new System.Drawing.Point(20, 268);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(116, 44);
            this.button27.TabIndex = 4;
            this.button27.Text = "Thêm";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.FlatAppearance.BorderSize = 90;
            this.button28.Location = new System.Drawing.Point(158, 268);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(119, 44);
            this.button28.TabIndex = 3;
            this.button28.Text = "Cập nhật";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.FlatAppearance.BorderSize = 90;
            this.button29.Location = new System.Drawing.Point(300, 268);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(119, 44);
            this.button29.TabIndex = 2;
            this.button29.Text = "Xóa";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.FlatAppearance.BorderSize = 90;
            this.button30.Location = new System.Drawing.Point(446, 268);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(119, 44);
            this.button30.TabIndex = 1;
            this.button30.Text = "Reset";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // dataGridView_diem
            // 
            this.dataGridView_diem.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_diem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_diem.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView_diem.Location = new System.Drawing.Point(20, 51);
            this.dataGridView_diem.Name = "dataGridView_diem";
            this.dataGridView_diem.RowHeadersVisible = false;
            this.dataGridView_diem.Size = new System.Drawing.Size(306, 195);
            this.dataGridView_diem.TabIndex = 0;
            this.dataGridView_diem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click_diem);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Menu;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label4);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(620, 100);
            this.panel7.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(175, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(250, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Phần mềm quản lí sinh viên";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel_lop.ResumeLayout(false);
            this.groupBox_lop.ResumeLayout(false);
            this.groupBox_lop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_lop)).EndInit();
            this.groupBox_gv.ResumeLayout(false);
            this.groupBox_gv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_gv)).EndInit();
            this.groupBox_sv.ResumeLayout(false);
            this.groupBox_sv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_sv)).EndInit();
            this.groupBox_mh.ResumeLayout(false);
            this.groupBox_mh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_mh)).EndInit();
            this.groupBox_khoa.ResumeLayout(false);
            this.groupBox_khoa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_khoa)).EndInit();
            this.groupBox_diem.ResumeLayout(false);
            this.groupBox_diem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_diem)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem heThongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chucNangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timKiemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thongTinSToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel_lop;
        private System.Windows.Forms.GroupBox groupBox_lop;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_khoahoc_l;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_tenlop_l;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_malop_l;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.DataGridView dataGridView_lop;
        private System.Windows.Forms.ComboBox comboBox_tenK_k;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox_sv;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textbox_masv;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.DataGridView dataGridView_sv;
        private System.Windows.Forms.RadioButton radioButton_nu;
        private System.Windows.Forms.RadioButton radioButton_nam;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_sdtSV;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_dichi_sv;
        private System.Windows.Forms.TextBox textBox_hoten_sv;
        private System.Windows.Forms.GroupBox groupBox_gv;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_sdtGV;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox_dcGV;
        private System.Windows.Forms.TextBox textBox_hotenGV;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox_magv;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.DataGridView dataGridView_gv;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox_tenKhoa_GV;
        private System.Windows.Forms.ComboBox comboBox_tenLop;
        private System.Windows.Forms.GroupBox groupBox_khoa;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox_makhoa_k;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.DataGridView dataGridView_khoa;
        private System.Windows.Forms.GroupBox groupBox_diem;
        private System.Windows.Forms.ComboBox comboBox_masv_d;
        private System.Windows.Forms.ComboBox comboBox_mamh_d;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox_diemCK;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox_diemGK;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.DataGridView dataGridView_diem;
        private System.Windows.Forms.GroupBox groupBox_mh;
        private System.Windows.Forms.TextBox textBox_tenmh_mh;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox_mamh_mh;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.DataGridView dataGridView_mh;
        private System.Windows.Forms.TextBox textBox_tenKhoa_k;
        private System.Windows.Forms.ComboBox comboBox_mhGV;
        private System.Windows.Forms.DateTimePicker dateTimePicker_nsGV;
        private System.Windows.Forms.DateTimePicker dateTimePicker_nssv;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thoongsToolStripMenuItem;
    }
}

