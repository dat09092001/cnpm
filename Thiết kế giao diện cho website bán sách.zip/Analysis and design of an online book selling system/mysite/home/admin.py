from django.contrib import admin
from .models import dangnhap
admin.site.register(dangnhap)

# Register your models here.
